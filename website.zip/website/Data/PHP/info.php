<?php
    require($_SERVER['DOCUMENT_ROOT'].'/Data/PHP/Server.php');
    echo GetIpFrom("114.114.114.114");
?>